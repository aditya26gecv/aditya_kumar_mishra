-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2026 at 04:46 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_health`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `disease_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `specialization`, `mobile`, `disease_id`) VALUES
(1, 'Dr. Sharma', 'General Physician', '9876500001', 1),
(2, 'Dr. Rakesh Verma', 'General Physician', '9876500002', 1),
(3, 'Dr. Neha Kapoor', 'General Physician', '9876500003', 1),
(4, 'Dr. Mehta', 'Endocrinologist', '9876500004', 2),
(5, 'Dr. Anjali Singh', 'Diabetologist', '9876500005', 2),
(6, 'Dr. Raj Malhotra', 'Endocrinologist', '9876500006', 2),
(7, 'Dr. Arvind Kumar', 'Cardiologist', '9876500007', 3),
(8, 'Dr. Pooja Sharma', 'Cardiologist', '9876500008', 3),
(9, 'Dr. Sandeep Roy', 'Cardiologist', '9876500009', 3),
(10, 'Dr. Vivek Anand', 'Cardiologist', '9876500010', 3),
(11, 'Dr. Singh', 'Neurologist', '9876500011', 4),
(12, 'Dr. Kiran Rao', 'Neurologist', '9876500012', 4),
(13, 'Dr. Manish Tiwari', 'Neurologist', '9876500013', 4),
(14, 'Dr. Aditi Jain', 'Pulmonologist', '9876500014', 5),
(15, 'Dr. Rohit Yadav', 'Pulmonologist', '9876500015', 5),
(16, 'Dr. Sunita Das', 'Pulmonologist', '9876500016', 5),
(17, 'Dr. Mahesh Gupta', 'Orthopedic', '9876500017', 6),
(18, 'Dr. Alok Mishra', 'Orthopedic', '9876500018', 6),
(19, 'Dr. Priya Nair', 'Orthopedic', '9876500019', 6),
(20, 'Dr. Sneha Iyer', 'Dermatologist', '9876500020', 7),
(21, 'Dr. Tarun Bansal', 'Dermatologist', '9876500021', 7),
(22, 'Dr. Reena Thomas', 'Dermatologist', '9876500022', 7),
(23, 'Dr. Amit Joshi', 'Psychiatrist', '9876500023', 8),
(24, 'Dr. Kavita Rao', 'Psychiatrist', '9876500024', 8),
(25, 'Dr. Rahul Sinha', 'Psychiatrist', '9876500025', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
