<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5" style="min-height: 550px;">
  <h3>Available Doctors</h3>

  <table class="table table-bordered">
    <tr>
      <th>Name</th>
      <th>Specialization</th>
      <th>Contact</th>
    </tr>
    <tr><td>Dr. Amit Sharma</td><td>General Physician</td><td>9876543210</td></tr>
    <tr><td>Dr. Priya Verma</td><td>Pediatrician</td><td>9876543211</td></tr>
    <tr><td>Dr. Rajesh Gupta</td><td>Cardiologist</td><td>9876543212</td></tr>
    <tr><td>Dr. Sneha Singh</td><td>Dermatologist</td><td>9876543213</td></tr>
    <tr><td>Dr. Anil Kumar</td><td>ENT Specialist</td><td>9876543214</td></tr>
    <tr><td>Dr. Ritu Aggarwal</td><td>Gynecologist</td><td>9876543215</td></tr>
    <tr><td>Dr. Manoj Yadav</td><td>Neurologist</td><td>9876543216</td></tr>
    <tr><td>Dr. Neha Jain</td><td>Orthopedic</td><td>9876543217</td></tr>
    <tr><td>Dr. Vikram Rathore</td><td>Endocrinologist</td><td>9876543218</td></tr>
    <tr><td>Dr. Alka Mishra</td><td>General Physician</td><td>9876543219</td></tr>
    <tr><td>Dr. Karan Mehta</td><td>Pediatrician</td><td>9876543220</td></tr>
    <tr><td>Dr. Sonia Kapoor</td><td>Cardiologist</td><td>9876543221</td></tr>
    <tr><td>Dr. Deepak Verma</td><td>Dermatologist</td><td>9876543222</td></tr>
    <tr><td>Dr. Pooja Sharma</td><td>ENT Specialist</td><td>9876543223</td></tr>
    <tr><td>Dr. Rakesh Sinha</td><td>Gynecologist</td><td>9876543224</td></tr>
    <tr><td>Dr. Meena Gupta</td><td>Neurologist</td><td>9876543225</td></tr>
    <tr><td>Dr. Harsh Vardhan</td><td>Orthopedic</td><td>9876543226</td></tr>
    <tr><td>Dr. Kavita Rathi</td><td>Endocrinologist</td><td>9876543227</td></tr>
    <tr><td>Dr. Suresh Patil</td><td>General Physician</td><td>9876543228</td></tr>
    <tr><td>Dr. Nidhi Saxena</td><td>Pediatrician</td><td>9876543229</td></tr>
    <tr><td>Dr. Anupam Choudhary</td><td>Cardiologist</td><td>9876543230</td></tr>
    <tr><td>Dr. Shalini Rao</td><td>Dermatologist</td><td>9876543231</td></tr>
    <tr><td>Dr. Vikas Bhatia</td><td>ENT Specialist</td><td>9876543232</td></tr>
    <tr><td>Dr. Manisha Tiwari</td><td>Gynecologist</td><td>9876543233</td></tr>
    <tr><td>Dr. Rohit Malhotra</td><td>Neurologist</td><td>9876543234</td></tr>
    <tr><td>Dr. Shweta Nair</td><td>Orthopedic</td><td>9876543235</td></tr>
    <tr><td>Dr. Amitabh Joshi</td><td>Endocrinologist</td><td>9876543236</td></tr>
    <tr><td>Dr. Rekha Sharma</td><td>General Physician</td><td>9876543237</td></tr>
    <tr><td>Dr. Mohit Arora</td><td>Pediatrician</td><td>9876543238</td></tr>
    <tr><td>Dr. Priyanka Dubey</td><td>Cardiologist</td><td>9876543239</td></tr>
  </table>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>